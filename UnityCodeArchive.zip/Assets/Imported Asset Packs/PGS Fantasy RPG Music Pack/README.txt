You are free to use this for your Free and Commercial Projects.
For Game, Animation, Movie, Podcast, Youtube Video, Streaming.

As long you credits JP SOUNDWORKS.
and put this link on your Video/Podcast
/Stream description: 

Link: https://www.youtube.com/c/JPSoundworks/

For Example:
"Music by JP Soundworks (https://www.youtube.com/c/JPSoundworks/)"

---

Additionally you can also Credit Platonic Game Studio, but not required.

For Example:
Music by JP Soundworks, Pack Published by Platonic Game Studio.

--

DO NOT REPOST OR SELL THIS MUSIC, PLEASE SUPPORT THE CREATOR
BY DOWNLOADING FROM LEGAL SOURCES ONLY.

--

All music are ogg format with loop support. Works well with
many game engine that support OGG format.

--

(C) 2019 - 2020 JP Soundoworks
(P) 2019 - 2020 Platonic Game Studio

Learn More About PLATONIC GAME STUDIO https://store.steampowered.com/developer/platonicgamestudio

Learn more about JP SOUNDWORKS
https://www.youtube.com/c/JPSoundworks/

CREATIVE COMMONS CC 4.0 BY 
https://creativecommons.org/licenses/by/4.0/